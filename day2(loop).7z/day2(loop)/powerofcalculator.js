// let i = 1;
// let base = 2;
// let exponent =3;
// let result = 1;

// while(i<=exponent){
//     result=result*base;
//     i++;

// }
// console.log(result);


let result = 1;
let exponent = 3;
let base = 2;

for(let i = 1; i<=3;i++){
    result= result*base;
}
console.log(result);