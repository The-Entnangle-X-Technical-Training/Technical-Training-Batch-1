
let sum = 0;
let num = 78;

for(let i = 1; i<=num ;i++ ){
    if(i%10){
    sum = sum+i;
    }
}
console.log(sum);