let sum = 0;
let num = 16;
for(let i = 1; i<=num;i++){
    sum = sum+i;
}
console.log("sum of natural number:",sum)