let N = 20;
let count = 0;

for (let i = 1; i <= N; i++) {
  if (i % 2 === 0) {
    count++;
  }
}

console.log("Even count:", count);

//Count Even Numbers (1 to N)