let n = 11;
let sum = 0;
let i = 1;

while(i<=n){
    if(i%2 !=0){
        sum = sum+i;
    }
    i++;
}
console.log("sum od old:",sum);


