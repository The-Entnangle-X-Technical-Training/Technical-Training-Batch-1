// sum os squ

let num = 8;
let sum = 0;
let i = 1;
while(i<=num){
    sum+=i*i;
    i++;
}
console.log(sum);