let sum = 0;
let num =4;
let i = 1;

while(i<=num){
    
    sum+=i*i;
    i++;
}
console.log(sum);