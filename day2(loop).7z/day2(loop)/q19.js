for (let i = 1; i <= 10; i++) {
  console.log(i * i);
}


//Squares of First 10 Numbers