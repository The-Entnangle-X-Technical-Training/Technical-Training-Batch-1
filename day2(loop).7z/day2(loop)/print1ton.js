// let n= 8;
// for(let i = 1;i<=n;i++){
//     console.log(i)
// }


let i =1;
while(i<=10){
    console.log(i);
    i++;
}
