let i =1;
while(i<=30){
    if(i%2 !=0){  
        console.log(i);
    }//given divide krte or jo reminder vo pirnt ho tha h (i%2 !=0)
    i++;
    
}